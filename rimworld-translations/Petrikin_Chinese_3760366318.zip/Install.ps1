param([string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\RimWorld')
$ErrorActionPreference = 'Stop'
try {
    if (Get-Process -Name RimWorldWin64,RimWorldWin -ErrorAction SilentlyContinue) { throw 'Please close RimWorld before installing.' }
    if (-not (Test-Path -LiteralPath (Join-Path $GamePath 'Data\Core\About\About.xml'))) { throw "RimWorld not found: $GamePath. Use Install.ps1 -GamePath 'YOUR GAME FOLDER'." }
    $source = Join-Path $PSScriptRoot 'Petrikin_Chinese'
    [xml]$metadata = Get-Content -LiteralPath (Join-Path $source 'About\About.xml') -Raw -Encoding UTF8
    if ($metadata.ModMetaData.packageId -ne 'local.pesky.petrikin.chinesesimplified') { throw 'Unexpected source package.' }
    $mods = Join-Path $GamePath 'Mods'
    New-Item -ItemType Directory -Path $mods -Force | Out-Null
    $target = Join-Path $mods 'Petrikin_Chinese'
    if (Test-Path -LiteralPath $target) {
        [xml]$existing = Get-Content -LiteralPath (Join-Path $target 'About\About.xml') -Raw -Encoding UTF8
        if ($existing.ModMetaData.packageId -ne $metadata.ModMetaData.packageId) { throw 'Destination belongs to another mod; nothing was replaced.' }
        $backupRoot = Join-Path $GamePath 'TranslationBackups'
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        $backup = Join-Path $backupRoot ('Petrikin_Chinese.' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
        Move-Item -LiteralPath $target -Destination $backup
        Write-Host "Previous translation backed up to: $backup"
    }
    try {
        Copy-Item -LiteralPath $source -Destination $target -Recurse
        Get-ChildItem -LiteralPath $source -Recurse -File | ForEach-Object {
            $relative = $_.FullName.Substring($source.Length).TrimStart('\')
            if ((Get-FileHash -LiteralPath $_.FullName).Hash -ne (Get-FileHash -LiteralPath (Join-Path $target $relative)).Hash) { throw "Copy verification failed: $relative" }
        }
    } catch {
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
        if ($backup -and (Test-Path -LiteralPath $backup)) { Move-Item -LiteralPath $backup -Destination $target }
        throw
    }
    Write-Host "Installed and verified: $target" -ForegroundColor Green
    Write-Host 'Enable the translation after Pesky''s Petrikin Xenotype in the in-game Mods menu.'
    Write-Host 'Select Simplified Chinese and restart RimWorld. Original mod files were not changed.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host 'If access is denied, run Install.cmd as administrator or copy Petrikin_Chinese into RimWorld\Mods manually.'
    exit 1
}
